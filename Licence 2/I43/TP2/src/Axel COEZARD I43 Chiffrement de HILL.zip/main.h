void cypher(void);

void decypher(void);

void getKeyMessage(void);

void inverse(void);